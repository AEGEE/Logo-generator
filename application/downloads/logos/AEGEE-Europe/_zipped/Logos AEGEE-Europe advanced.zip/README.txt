##################################################
## 						##
##  LOGO AEGEE-EUROPE				##
##						##
##################################################


ABOUT
    This archive contains the logo's of AEGEE-Europe.


USAGE
  1.The files in this archive may only be used by those 
    who have the right to use it or have the permission 
    from the Secretary General of AEGEE-Europe.

  2.The logo's provided should be used in accordance with
    the Visual Identity of AEGEE-Europe.


INQUIRIES
    For questions or issues please contact headoffice@aegee.org



-----------------------------------------------------

Version: 1.0
Date: 1-10-2013
Author: Maurits Korse

